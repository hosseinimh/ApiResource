<?php

return [
    'token_invalid' => 'Session is expired. Please login again.',
    'token_expired' => 'Session is expired. Please login again.',
    'token_black_listed' => 'Session is expired. Please login again.',
    'token_not_found' => 'Session is expired. Please login again.',
];
