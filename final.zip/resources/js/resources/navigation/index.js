import AuthRoute from "./AuthRoute";

export { AuthRoute };
