import Page from "./Page";
import InsertPage from "./InsertPage";

export { Page, InsertPage };
