export const MESSAGE_TYPES = {
    INFO: "info",
    SUCCESS: "success",
    ERROR: "error",
};
