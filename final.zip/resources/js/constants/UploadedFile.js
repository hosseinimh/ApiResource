export const UPLOADED_FILE = {
    OK: 1,
    ERROR: 2,
    UPLOAD_ERROR: 3,
    MIME_TYPE_ERROR: 4,
    NOT_UPLOADED_ERROR: 5,
    EXCEPTION: 6,
};
